<?php
/**
 * FILE: proses_edit.php
 * FUNGSI: Mengolah data dari form edit, mengurus pergantian berkas foto, dan menjalankan query UPDATE.
 */

require "koneksi.php";

// Pastikan proses diakses melalui tombol submit bertuliskan 'update'
if (isset($_POST['update'])) {
    
    $id_produk   = mysqli_real_escape_string($koneksi, $_POST['id_produk']);
    $nama_produk = mysqli_real_escape_string($koneksi, $_POST['nama_produk']);
    $id_kategori = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $harga       = $_POST['harga'];
    $stok        = $_POST['stok'];
    $deskripsi   = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
    
    $foto_lama   = $_POST['foto_lama'];
    $nama_file   = $_FILES['foto']['name'];
    $tmp_file    = $_FILES['foto']['tmp_name'];

    // Cek apakah user mengunggah foto baru
    if (!empty($nama_file)) {
        // Jika ada foto baru, buat nama unik baru menggunakan timestamp
        $foto_baru = time() . "_" . $nama_file;
        $path_folder = "uploads/" . $foto_baru;
        
        // Pindahkan file gambar baru ke folder uploads/
        if (move_uploaded_file($tmp_file, $path_folder)) {
            // Hapus file foto lama di folder uploads jika filenya memang ada
            if (file_exists("uploads/" . $foto_lama) && !empty($foto_lama)) {
                unlink("uploads/" . $foto_lama);
            }
        } else {
            echo "<script>alert('Gagal mengunggah foto baru!'); window.history.back();</script>";
            exit();
        }
    } else {
        // Jika user mengosongkan input file, gunakan kembali nama file foto lama
        $foto_baru = $foto_lama;
    }

    // Jalankan query UPDATE data ke database berdasarkan id_produk (string)
    $query_update = "UPDATE produk SET 
                        id_kategori = '$id_kategori',
                        nama_produk = '$nama_produk',
                        deskripsi = '$deskripsi',
                        harga = $harga,
                        stok = $stok,
                        foto = '$foto_baru'
                     WHERE id_produk = '$id_produk'";

    if (mysqli_query($koneksi, $query_update)) {
        echo "<script>
                alert('Produk dengan ID $id_produk berhasil diperbarui!');
                window.location = 'index.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal memperbarui data ke database.'); 
                window.history.back();
              </script>";
    }

} else {
    // Jika diakses langsung tanpa submit form, alihkan kembali ke halaman utama
    header("Location: index.php");
    exit();
}
?>