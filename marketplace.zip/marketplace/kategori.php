<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require "koneksi.php";

$query = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY id_kategori ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manajemen Kategori</title>

<style>

body{
    margin:0;
    font-family:Arial, sans-serif;
    background:#f5f5f5;
}

header{
    background:#007bff;
    color:white;
    padding:18px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.container{
    width:90%;
    margin:30px auto;
}

.menu{
    display:flex;
    justify-content:space-between;
    margin-bottom:20px;
}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
}

th{
    background:#007bff;
    color:white;
    padding:12px;
}

td{
    padding:12px;
    text-align:center;
    border-bottom:1px solid #ddd;
}

.btn{
    text-decoration:none;
    color:white;
    padding:8px 15px;
    border-radius:5px;
}

.btn-tambah{
    background:#28a745;
}

.btn-edit{
    background:#ffc107;
    color:black;
}

.btn-hapus{
    background:#dc3545;
}

.btn-kembali{
    background:#6c757d;
}

</style>

</head>

<body>

<header>

<h2>Manajemen Kategori</h2>

<a href="index.php" class="btn btn-kembali">

Kembali

</a>

</header>

<div class="container">

<div class="menu">

<h3>Daftar Kategori</h3>

<a href="tambah_kategori.php" class="btn btn-tambah">

+ Tambah Kategori

</a>

</div>

<table>

<tr>

<th>No</th>
<th>ID Kategori</th>
<th>Nama Kategori</th>
<th>Aksi</th>

</tr>

<?php

$no=1;

while($row=mysqli_fetch_assoc($query)){

?>

<tr>

<td><?= $no++; ?></td>

<td><?= $row['id_kategori']; ?></td>

<td><?= $row['nama_kategori']; ?></td>

<td>

<a
href="edit_kategori.php?id=<?= $row['id_kategori']; ?>"
class="btn btn-edit">

Edit

</a>

<a
href="hapus_kategori.php?id=<?= $row['id_kategori']; ?>"
class="btn btn-hapus"
onclick="return confirm('Yakin ingin menghapus kategori?')">

Hapus

</a>

</td>

</tr>

<?php
}
?>

</table>

</div>

</body>
</html>