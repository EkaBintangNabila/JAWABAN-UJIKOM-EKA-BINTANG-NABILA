<?php
session_start();

if(!isset($_SESSION['login'])){
    header("Location: login.php");
    exit;
}

require "koneksi.php";

$id = $_GET['id'];

// Hapus data pesanan
$hapus = mysqli_query($koneksi,"DELETE FROM pesanan WHERE id_pesanan='$id'");

if($hapus){

    echo "<script>

    alert('Pesanan berhasil dihapus!');

    window.location='pesanan.php';

    </script>";

}else{

    echo "<script>

    alert('Pesanan gagal dihapus!');

    window.location='pesanan.php';

    </script>";

}
?>