<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require "koneksi.php";
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Tambah Kategori</title>

<style>

body{
    margin:0;
    font-family:Arial,sans-serif;
    background:#f5f5f5;
}

header{
    background:#007bff;
    color:white;
    padding:18px 30px;
}

.container{
    width:500px;
    margin:40px auto;
    background:white;
    padding:25px;
    border-radius:8px;
    box-shadow:0 2px 8px rgba(0,0,0,.2);
}

h2{
    margin-top:0;
    text-align:center;
}

label{
    display:block;
    margin-top:15px;
    margin-bottom:8px;
}

input{
    width:100%;
    padding:10px;
    border:1px solid #ccc;
    border-radius:5px;
    box-sizing:border-box;
}

.button{
    margin-top:25px;
    display:flex;
    justify-content:space-between;
}

.btn{
    text-decoration:none;
    color:white;
    padding:10px 18px;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

.btn-simpan{
    background:#28a745;
}

.btn-kembali{
    background:#6c757d;
}

</style>

</head>

<body>

<header>

<h2>Tambah Kategori</h2>

</header>

<div class="container">

<form action="proses_tambah_kategori.php" method="POST">

<label>ID Kategori</label>

<input
type="text"
name="id_kategori"
placeholder="Contoh : KTG05"
required>

<label>Nama Kategori</label>

<input
type="text"
name="nama_kategori"
placeholder="Masukkan Nama Kategori"
required>

<div class="button">

<button
type="submit"
class="btn btn-simpan">

Simpan

</button>

<a
href="kategori.php"
class="btn btn-kembali">

Kembali

</a>

</div>

</form>

</div>

</body>
</html>