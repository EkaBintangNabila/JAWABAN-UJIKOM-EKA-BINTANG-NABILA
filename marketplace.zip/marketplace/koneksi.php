<?php
/**
 * FILE: koneksi.php
 * FUNGSI: Menghubungkan aplikasi PHP ke database MySQL "db_marketplace"
 *         File ini nanti akan dipanggil (include) di semua halaman
 *         yang butuh akses database, jadi cukup ditulis SEKALI di sini.
 */

// --- Pengaturan koneksi database ---
$host     = "localhost";        // alamat server database (biasanya localhost saat development)
$username = "root";             // username MySQL (default XAMPP/Laragon = root)
$password = "";                 // password MySQL (default XAMPP/Laragon = kosong)
$database = "db_marketplace";   // nama database yang sudah kita buat di step 1

/**
 * mysqli_connect()
 * Fungsi: membuka koneksi ke server MySQL menggunakan data di atas.
 * Hasilnya disimpan ke variabel $koneksi, dan akan dipakai
 * di semua query (SELECT, INSERT, UPDATE, DELETE) di halaman lain.
 */
$koneksi = mysqli_connect($host, $username, $password, $database);

/**
 * Pengecekan koneksi
 * Fungsi: menghentikan program dan menampilkan pesan error
 * apabila koneksi ke database GAGAL (misalnya database belum dibuat,
 * atau username/password salah).
 */
if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

/**
 * mysqli_set_charset()
 * Fungsi: memastikan data yang keluar-masuk database menggunakan
 * karakter UTF-8, supaya teks seperti huruf é, atau simbol Rp
 * tidak tampil aneh/rusak (encoding error).
 */
mysqli_set_charset($koneksi, "utf8mb4");