<?php
session_start();
require "koneksi.php";

// Mengecek apakah form login dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Mengambil data dari form
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Mencari data admin berdasarkan email
    $query = mysqli_query($koneksi, "SELECT * FROM admin WHERE email='$email'");

    // Jika email ditemukan
    if(mysqli_num_rows($query) == 1){

        $admin = mysqli_fetch_assoc($query);

        // Cek password
        if($password == $admin['password']){

            // Membuat session
            $_SESSION['login'] = true;
            $_SESSION['id_admin'] = $admin['id_admin'];
            $_SESSION['nama_admin'] = $admin['nama'];

            // Pindah ke Dashboard
            header("Location: index.php");
            exit;

        }else{

            // Password salah
            header("Location: login.php?error=Password Salah");
            exit;

        }

    }else{

        // Email tidak ditemukan
        header("Location: login.php?error=Email Tidak Ditemukan");
        exit;

    }

}else{

    // Jika file dibuka langsung
    header("Location: login.php");
    exit;
}
?>