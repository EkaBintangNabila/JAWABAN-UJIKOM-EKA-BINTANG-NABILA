<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require "koneksi.php";

// Mengecek apakah id dikirim
if (!isset($_GET['id'])) {
    die("ID kategori tidak ditemukan.");
}

$id = $_GET['id'];

// Mengecek apakah kategori masih digunakan produk
$cek = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_kategori='$id'");

if(mysqli_num_rows($cek) > 0){

    echo "<script>

    alert('Kategori tidak bisa dihapus karena masih digunakan oleh produk!');

    window.location='kategori.php';

    </script>";

    exit;
}

// Menghapus kategori
$hapus = mysqli_query($koneksi, "DELETE FROM kategori WHERE id_kategori='$id'");

if($hapus){

    echo "<script>

    alert('Kategori berhasil dihapus!');

    window.location='kategori.php';

    </script>";

}else{

    echo "<script>

    alert('Kategori gagal dihapus!');

    window.location='kategori.php';

    </script>";

}
?>