<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require "koneksi.php";

$id = $_POST['id_kategori'];
$nama = $_POST['nama_kategori'];

$update = mysqli_query($koneksi,"
UPDATE kategori
SET nama_kategori='$nama'
WHERE id_kategori='$id'
");

if($update){

    echo "<script>
    alert('Kategori berhasil diperbarui!');
    window.location='kategori.php';
    </script>";

}else{

    echo "<script>
    alert('Kategori gagal diperbarui!');
    history.back();
    </script>";

}
?>