<?php
require "koneksi.php";

// Ambil data pencarian
$cari = isset($_GET['cari']) ? $_GET['cari'] : "";
$kategori = isset($_GET['kategori']) ? $_GET['kategori'] : "";

// Query dasar
$sql = "SELECT produk.*, kategori.nama_kategori
        FROM produk
        JOIN kategori
        ON produk.id_kategori = kategori.id_kategori
        WHERE 1";

// Jika ada pencarian
if($cari != ""){
    $sql .= " AND produk.nama_produk LIKE '%$cari%'";
}

// Jika memilih kategori
if($kategori != ""){
    $sql .= " AND produk.id_kategori='$kategori'";
}

$sql .= " ORDER BY produk.created_at DESC";

$query = mysqli_query($koneksi,$sql);

if(!$query){
    die(mysqli_error($koneksi));
}


?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Marketplace Online</title>

<style>

body{
    margin:0;
    font-family:Arial,sans-serif;
    background:#f5f5f5;
}

header{
    background:#007bff;
    color:white;
    padding:18px;
    text-align:center;
}

.container{
    width:90%;
    margin:30px auto;
}

.grid{
    display:flex;
    flex-wrap:wrap;
    gap:20px;
}

.card{

    width:250px;
    background:white;
    border-radius:8px;
    overflow:hidden;
    box-shadow:0 2px 8px rgba(0,0,0,.15);

}

.card img{

    width:100%;
    height:180px;
    object-fit:cover;

}

.card-body{

    padding:15px;

}

.card-body h3{

    margin:0;

}

.kategori{

    color:#777;
    margin:8px 0;

}

.harga{

    color:green;
    font-weight:bold;
    font-size:18px;

}

.stok{

    color:#444;

}

.btn{

display:block;

text-align:center;

margin-top:15px;

padding:10px;

background:#007bff;

color:white;

text-decoration:none;

border-radius:5px;

}

.btn:hover{

background:#0056b3;

}

</style>

</head>

<body>

<header>

<h1>Marketplace Online</h1>

</header>

<div class="container">
    <form method="GET" style="margin-bottom:25px; display:flex; gap:10px;">

<input
type="text"
name="cari"
placeholder="Cari produk..."
value="<?php echo $cari; ?>"
style="padding:10px; width:250px;">

<select
name="kategori"
style="padding:10px;">

<option value="">Semua Kategori</option>

<?php

$dataKategori = mysqli_query($koneksi,"SELECT * FROM kategori");

while($k=mysqli_fetch_assoc($dataKategori)){

?>

<option
value="<?php echo $k['id_kategori'];?>"
<?php if($kategori==$k['id_kategori']) echo "selected"; ?>>

<?php echo $k['nama_kategori'];?>

</option>

<?php
}
?>

</select>

<button
type="submit"
class="btn"
style="margin-top:0; width:120px;">

Cari

</button>

</form>

<div class="grid">

<?php

while($produk=mysqli_fetch_assoc($query)){

?>

<div class="card">

<img src="uploads/<?php echo $produk['foto'];?>">

<div class="card-body">

<h3><?php echo $produk['nama_produk'];?></h3>

<p class="kategori">
<?php echo $produk['nama_kategori'];?>
</p>

<p class="harga">

Rp <?php echo number_format($produk['harga'],0,',','.');?>

</p>

<p class="stok">

Stok :
<?php echo $produk['stok'];?>

</p>

<a
class="btn"
href="detail.php?id=<?php echo $produk['id_produk'];?>">

Lihat Detail

</a>

</div>

</div>

<?php
}
?>

</div>

</div>

</body>
</html>