<?php
session_start();

if(!isset($_SESSION['login'])){
    header("Location: login.php");
    exit;
}

require "koneksi.php";

$query = mysqli_query($koneksi,"
SELECT
pesanan.*,
produk.nama_produk
FROM pesanan
JOIN produk
ON pesanan.id_produk = produk.id_produk
ORDER BY pesanan.tanggal_pesanan DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">

<title>Data Pesanan</title>

<style>

body{

font-family:Arial,sans-serif;
background:#f5f5f5;
margin:0;

}

header{

background:#007bff;
padding:18px;
color:white;
display:flex;
justify-content:space-between;
align-items:center;

}

.container{

width:95%;
margin:30px auto;

}

table{

width:100%;
border-collapse:collapse;
background:white;

}

table th{

background:#007bff;
color:white;
padding:12px;

}

table td{

padding:10px;
text-align:center;
border-bottom:1px solid #ddd;

}

.btn{

padding:10px 18px;
background:#6c757d;
color:white;
text-decoration:none;
border-radius:5px;

}
.btn-hapus{
    background:#dc3545;
    color:white;
    padding:8px 12px;
    text-decoration:none;
    border-radius:5px;
}

.btn-hapus:hover{
    background:#b02a37;
}

</style>

</head>

<body>

<header>

<h2>Data Pesanan</h2>

<a href="index.php" class="btn">

Kembali

</a>

</header>

<div class="container">

<table>

<tr>

<th>No</th>

<th>ID Pesanan</th>

<th>Produk</th>

<th>Nama Pembeli</th>

<th>No HP</th>

<th>Jumlah</th>

<th>Total Harga</th>

<th>Tanggal</th>

<th>Aksi</th>

</tr>

<?php

$no=1;

while($row=mysqli_fetch_assoc($query)){

?>

<tr>

<td><?= $no++; ?></td>

<td><?= $row['id_pesanan']; ?></td>

<td><?= $row['nama_produk']; ?></td>

<td><?= $row['nama_pembeli']; ?></td>

<td><?= $row['no_hp']; ?></td>

<td><?= $row['jumlah']; ?></td>

<td>

Rp <?= number_format($row['total_harga'],0,",",".");?>

</td>

<td><?= $row['tanggal_pesanan']; ?></td>
<td>
    <a href="hapus_pesanan.php?id=<?= $row['id_pesanan']; ?>"
       onclick="return confirm('Yakin ingin menghapus pesanan ini?')"
       class="btn-hapus">
       Hapus
    </a>
</td>

</tr>

<?php } ?>

</table>

</div>

</body>

</html>