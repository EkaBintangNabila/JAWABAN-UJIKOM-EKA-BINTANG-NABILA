<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require "koneksi.php";

$id = $_POST['id_kategori'];
$nama = $_POST['nama_kategori'];

$simpan = mysqli_query($koneksi,"
INSERT INTO kategori
(id_kategori,nama_kategori)
VALUES
('$id','$nama')
");

if($simpan){

    echo "<script>

    alert('Kategori berhasil ditambahkan!');

    window.location='kategori.php';

    </script>";

}else{

    echo "<script>

    alert('Kategori gagal ditambahkan!');

    history.back();

    </script>";

}
?>