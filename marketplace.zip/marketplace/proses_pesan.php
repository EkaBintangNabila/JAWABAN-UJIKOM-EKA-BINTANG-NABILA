<?php
require "koneksi.php";

// Mengambil data dari form
$id_produk      = $_POST['id_produk'];
$nama_pembeli   = $_POST['nama_pembeli'];
$no_hp          = $_POST['no_hp'];
$jumlah         = $_POST['jumlah'];
$harga          = $_POST['harga'];

// Menghitung total harga
$total_harga = $harga * $jumlah;

// Mengambil stok produk
$data_produk = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk='$id_produk'");
$produk = mysqli_fetch_assoc($data_produk);

$stok = $produk['stok'];

// Cek apakah stok mencukupi
if($jumlah > $stok){
    echo "<script>
            alert('Stok produk tidak mencukupi!');
            history.back();
          </script>";
    exit;
}

// Membuat ID Pesanan Otomatis
$query = mysqli_query($koneksi, "SELECT MAX(id_pesanan) AS kode FROM pesanan");
$data = mysqli_fetch_assoc($query);

if($data['kode'] == ""){
    $id_pesanan = "ORD0001";
}else{
    $angka = substr($data['kode'], 3);
    $angka++;
    $id_pesanan = "ORD".str_pad($angka,4,"0",STR_PAD_LEFT);
}

// Simpan ke tabel pesanan
$simpan = mysqli_query($koneksi, "
INSERT INTO pesanan
(id_pesanan,id_produk,nama_pembeli,no_hp,jumlah,total_harga)
VALUES
('$id_pesanan',
'$id_produk',
'$nama_pembeli',
'$no_hp',
'$jumlah',
'$total_harga')
");

// Jika berhasil
if($simpan){

    // Mengurangi stok
    $stok_baru = $stok - $jumlah;

    mysqli_query($koneksi,"
    UPDATE produk
    SET stok='$stok_baru'
    WHERE id_produk='$id_produk'
    ");

    echo "<script>
            alert('Pesanan berhasil dibuat!');
            window.location='bukti_pesanan.php?id=$id_pesanan';
          </script>";

}else{

    echo "<script>
            alert('Pesanan gagal!');
            history.back();
          </script>";
}
?>