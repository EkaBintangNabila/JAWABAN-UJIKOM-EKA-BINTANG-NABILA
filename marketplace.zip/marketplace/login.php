<?php
session_start();

// Jika sudah login, langsung ke dashboard
if (isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html> 
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>

    <style>
        body{
            font-family: Arial, sans-serif;
            background:#f2f2f2;
        }

        .login-box{ 
            width:350px;
            margin:100px auto;
            background:white;
            padding:20px;
            border-radius:8px;
            box-shadow:0px 0px 8px rgba(0,0,0,0.2);
        }

        h2{
            text-align:center;
            margin-bottom:20px;
        }

        input{
            width:100%;
            padding:10px;
            margin:10px 0;
            border:1px solid #ccc;
            border-radius:5px;
            box-sizing:border-box;
        }

        button{
            width:100%;
            padding:10px;
            background:#007bff;
            color:white;
            border:none;
            border-radius:5px;
            cursor:pointer;
        }

        button:hover{
            background:#0056b3;
        }

        .error{
            color:red;
            text-align:center;
            margin-bottom:10px;
        }
    </style>

</head>
<body>

<div class="login-box">

    <h2>Login Admin</h2>

    <?php
    if(isset($_GET['error'])){
        echo "<div class='error'>Email atau Password Salah!</div>";
    }
    ?>

    <form action="proses_login.php" method="POST">

        <input
            type="email"
            name="email"
            placeholder="Masukkan Email"
            required>

        <input
            type="password"
            name="password"
            placeholder="Masukkan Password"
            required>

        <button type="submit">
            Login
        </button>

    </form>

</div>

</body>
</html>