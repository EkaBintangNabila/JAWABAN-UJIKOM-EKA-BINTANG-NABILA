<?php
/**
 * FILE: proses_tambah.php
 * FUNGSI: Mengolah data kiriman form, generate ID Produk PRDxxx, dan upload file foto.
 */

require "koneksi.php";

// Pastikan proses diakses melalui tombol submit form
if (isset($_POST['submit'])) {
    
    // 1. Ambil data dari form input dan bersihkan (mencegah SQL Injection sederhana)
    $nama_produk = mysqli_real_escape_string($koneksi, $_POST['nama_produk']);
    $id_kategori = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $harga       = $_POST['harga'];
    $stok        = $_POST['stok'];
    $deskripsi   = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);

    // 2. LOGIKA GENERATE KODE ID_PRODUK (Format: PRDxxx)
    // Cari id_produk paling besar/terakhir dari database
    $query_id  = "SELECT id_produk FROM produk ORDER BY id_produk DESC LIMIT 1";
    $hasil_id  = mysqli_query($koneksi, $query_id);
    $data_id   = mysqli_fetch_assoc($hasil_id);

    if ($data_id) {
        // Jika data ada, ambil string kodenya (misal 'PRD003')
        $kode_terakhir = $data_id['id_produk'];
        // Potong dan ambil angkanya saja mulai dari indeks ke-3 ('003')
        $angka_terakhir = substr($kode_terakhir, 3);
        // Konversi ke integer lalu tambahkan 1 (3 + 1 = 4)
        $angka_baru = (int)$angka_terakhir + 1;
        // Gabungkan kembali string 'PRD' dengan angka baru berformat 3 digit padding nol ('PRD004')
        $id_produk_baru = "PRD" . sprintf("%03d", $angka_baru);
    } else {
        // Jika tabel produk benar-benar masih kosong, set kode awal ke PRD001
        $id_produk_baru = "PRD001";
    }

    // 3. PROSES UPLOAD FOTO
    $nama_file = $_FILES['foto']['name'];
    $tmp_file  = $_FILES['foto']['tmp_name'];
    
    // Membuat nama unik baru untuk file gambar agar tidak bentrok (contoh: 171829381_kaos.jpg)
    $foto_baru = time() . "_" . $nama_file;
    
    // Tentukan folder tempat menampung file upload
   
    $path_folder = "uploads/" . $foto_baru;

    // Pindahkan file dari folder sementara server ke folder uploads project kita
    if (move_uploaded_file($tmp_file, $path_folder)) {
        
        // 4. JALANKAN QUERY INSERT KE DATABASE
        $query_insert = "INSERT INTO produk (id_produk, id_kategori, nama_produk, deskripsi, harga, stok, foto) 
                         VALUES ('$id_produk_baru', '$id_kategori', '$nama_produk', '$deskripsi', $harga, $stok, '$foto_baru')";
        
        if (mysqli_query($koneksi, $query_insert)) {
            // Jika berhasil disimpan, redirect / alihkan ke halaman beranda
            echo "<script>
                    alert('Produk baru berhasil ditambahkan dengan ID: $id_produk_baru!');
                    window.location = 'index.php';
                  </script>";
        } else {
            // Jika query database gagal
            echo "<script>
                    alert('Gagal menyimpan data ke database.');
                    window.history.back();
                  </script>";
        }

    } else {
        // Jika proses pemindahan file gambar gagal
        echo "<script>
                alert('Gagal mengunggah gambar produk.');
                window.history.back();
              </script>";
    }

} else {
    // Jika diakses ilegal tanpa klik tombol submit, langsung tendang ke beranda
    header("Location: index.php");
    exit();
}
?>