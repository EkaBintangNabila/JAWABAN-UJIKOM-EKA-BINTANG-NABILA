<?php
/**
 * FILE: tambah.php
 * FUNGSI: Menampilkan form tambah produk dan melampirkan pilihan kategori secara dinamis.
 */

require "koneksi.php";

// Mengambil semua data kategori untuk pilihan di dropdown form
$query_kategori = "SELECT * FROM kategori ORDER BY nama_kategori ASC";
$hasil_kategori = mysqli_query($koneksi, $query_kategori);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk Baru</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 30px auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h2 { margin-top: 0; color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input[type="text"], .form-group input[type="number"], .form-group select, .form-group textarea {
            width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; font-size: 14px;
        }
        .form-group textarea { resize: vertical; height: 100px; }
        .btn-grup { display: flex; gap: 10px; margin-top: 20px; }
        .btn { padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 14px; cursor: pointer; border: none; }
        .btn-simpan { background-color: #28a745; color: white; }
        .btn-kembali { background-color: #6c757d; color: white; text-align: center; }
    </style>
</head>
<body> 

<div class="container">
    <h2>Form Tambah Produk</h2>
    
    
    <form action="proses_tambah.php" method="POST"enctype="multipart/form-data">
        
        <div class="form-group">
            <label for="nama_produk">Nama Produk</label>
            <input type="text" id="nama_produk" name="nama_produk" required placeholder="Contoh: Kemeja Flanel">
        </div>

        <div class="form-group">
            <label for="id_kategori">Kategori</label>
            <select id="id_kategori" name="id_kategori" required>
                <option value="">-- Pilih Kategori --</option>
                <?php while ($kat = mysqli_fetch_assoc($hasil_kategori)) { ?>
                    <option value="<?php echo $kat['id_kategori']; ?>">
                        <?php echo htmlspecialchars($kat['nama_kategori']); ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <div class="form-group">
            <label for="harga">Harga (Rp)</label>
            <input type="number" id="harga" name="harga" required placeholder="Contoh: 50000">
        </div>

        <div class="form-group">
            <label for="stok">Stok Awal</label>
            <input type="number" id="stok" name="stok" required placeholder="Contoh: 10" min="0">
        </div>

        <div class="form-group">
            <label for="deskripsi">Deskripsi Produk</label>
            <textarea id="deskripsi" name="deskripsi" placeholder="Tulis deskripsi lengkap produk di sini..."></textarea>
        </div>

        <div class="form-group">
            <label for="foto">Foto Produk</label>
            <input type="file" id="foto" name="foto" accept="image/*" required>
        </div>

        <div class="btn-grup">
            <button type="submit" name="submit" class="btn btn-simpan">Simpan Produk</button>
            <a href="index.php" class="btn btn-kembali">Kembali</a>
        </div>
    </form>
</div>

</body>
</html>