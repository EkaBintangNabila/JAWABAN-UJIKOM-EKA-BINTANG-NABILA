<?php
/**
 * FILE: index.php
 * FUNGSI: Dashboard Admin Marketplace/ beranda untuk katalog produk
 * Dilengkapi dengan CSS internal (digabung) dan tombol CRUD (Tambah, Edit, Delete).
 */
session_start();



if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
// Memanggil file koneksi database
require "koneksi.php";

// Menghitung total produk
$total_produk = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM produk"));

// Menghitung total kategori
$total_kategori = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM kategori"));

// Menghitung total pesanan
$total_pesanan = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM pesanan"));

// Query mengambil semua data produk beserta nama kategorinya
$query = "SELECT produk.*, kategori.nama_kategori
          FROM produk
          JOIN kategori ON produk.id_kategori = kategori.id_kategori
          ORDER BY produk.created_at DESC";

$hasil = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
body{
    font-family: Arial, sans-serif;
    background-color:#f5f5f5;
    margin:0;
}

.navbar{
    background:#007bff;
    color:white;
    padding:15px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.navbar h1{
    margin:0;
}

.container{
    width:90%;
    margin:20px auto;
}

.header-katalog{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

.grid-produk{
    display:flex;
    flex-wrap:wrap;
    gap:20px;
}

.card-produk{
    width:250px;
    background:white;
    border:1px solid #ddd;
    border-radius:8px;
    padding:15px;
    box-shadow:0 2px 5px rgba(0,0,0,0.1);
}

.card-produk img{
    width:100%;
    height:180px;
    object-fit:cover;
    border-radius:5px;
}

.btn{
    display:inline-block;
    text-decoration:none;
    padding:8px 15px;
    border-radius:5px;
    color:white;
    margin-top:5px;
}

.btn-tambah{
    background:#28a745;
}

.btn-edit{
    background:#ffc107;
    color:black;
}

.btn-delete{
    background:#dc3545;
}

.btn-logout{
    background:#dc3545;
}

.aksi-produk{
    display:flex;
    justify-content:space-between;
    margin-top:10px;
}

.harga{
    color:#28a745;
    font-weight:bold;
}

.kategori{
    color:#666;
}

.stok{
    color:#555;
}
.summary{
    display:flex;
    gap:20px;
    margin-bottom:30px;
}

.box{
    flex:1;
    background:white;
    border-radius:8px;
    padding:20px;
    text-align:center;
    box-shadow:0 2px 8px rgba(0,0,0,.15);
}

.box h3{
    margin:0;
    color:#666;
    font-size:18px;
}

.box h1{
    margin-top:10px;
    color:#007bff;
    font-size:36px;
}
</style>
    <title>Dashboard Admin</title>
</head>
<body>

    <header class="navbar">
        <h1>Dashboard Admin</h1>
        <a href="logout.php" class="btn btn-logout">
        Logout
    </a>
    </header>

    <main class="container">

    <div class="summary">

    <div class="box">
        <h3>Total Produk</h3>
        <h1><?php echo $total_produk; ?></h1>
    </div>

    <div class="box">
        <h3>Total Kategori</h3>
        <h1><?php echo $total_kategori; ?></h1>
    </div>

    <div class="box">
        <h3>Total Pesanan</h3>
        <h1><?php echo $total_pesanan; ?></h1>
    </div>

</div>
        
        <div class="header-katalog">
            <h2>Katalog Produk</h2>
            <div>

<a href="kategori.php" class="btn btn-edit">
    Kategori
</a>

<a href="pesanan.php" class="btn btn-edit">
    Data Pesanan
</a>

<a href="tambah.php" class="btn btn-tambah">
    + Tambah Produk
</a>
        </div>
        </div>

        <div class="grid-produk">
            <?php
            // Perulangan untuk menampilkan data produk dari database
            while ($produk = mysqli_fetch_assoc($hasil)) {
            ?>
                <div class="card-produk">
                    <div>
                        <img src="uploads/<?php echo htmlspecialchars($produk['foto']); ?>" 
                             alt="<?php echo htmlspecialchars($produk['nama_produk']); ?>">

                        <h3><?php echo htmlspecialchars($produk['nama_produk']); ?></h3>
                        <p class="kategori"><?php echo htmlspecialchars($produk['nama_kategori']); ?></p>
                        
                        <p class="harga">
                            Rp <?php echo number_format($produk['harga'], 0, ',', '.'); ?>
                        </p>
                        <p class="stok">Stok: <?php echo $produk['stok']; ?></p>
                    </div>

                    <div class="aksi-produk">
                        <a href="edit.php?id=<?php echo $produk['id_produk']; ?>" class="btn btn-edit">Edit</a>
                        <a href="delete.php?id=<?php echo $produk['id_produk']; ?>" 
                           class="btn btn-delete" 
                           onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">Hapus</a>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </main>

</body>
</html>