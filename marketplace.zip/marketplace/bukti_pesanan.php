<?php
require "koneksi.php";

if(!isset($_GET['id'])){
    die("Pesanan tidak ditemukan.");
}

$id = $_GET['id'];

$query = mysqli_query($koneksi,"
SELECT
pesanan.*,
produk.nama_produk
FROM pesanan
JOIN produk
ON pesanan.id_produk = produk.id_produk
WHERE pesanan.id_pesanan='$id'
");

if(mysqli_num_rows($query)==0){
    die("Data pesanan tidak ditemukan.");
}

$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Bukti Pesanan</title>

<style>

body{

font-family:Arial,sans-serif;
background:#f5f5f5;
margin:0;

}

.container{

width:500px;
margin:40px auto;
background:white;
padding:30px;
border-radius:8px;
box-shadow:0 0 10px rgba(0,0,0,.2);

}

h2{

text-align:center;
color:#28a745;

}

table{

width:100%;
margin-top:20px;

}

table td{

padding:10px;

}

.btn{

display:block;
margin-top:30px;
padding:12px;
text-align:center;
text-decoration:none;
background:#007bff;
color:white;
border-radius:5px;

}

</style>

</head>

<body>

<div class="container">

<h2>Pesanan Berhasil</h2>

<table>

<tr>

<td>ID Pesanan</td>

<td>:</td>

<td><?php echo $data['id_pesanan']; ?></td>

</tr>

<tr>

<td>Nama Pembeli</td>

<td>:</td>

<td><?php echo $data['nama_pembeli']; ?></td>

</tr>

<tr>

<td>No HP</td>

<td>:</td>

<td><?php echo $data['no_hp']; ?></td>

</tr>

<tr>

<td>Produk</td>

<td>:</td>

<td><?php echo $data['nama_produk']; ?></td>

</tr>

<tr>

<td>Jumlah</td>

<td>:</td>

<td><?php echo $data['jumlah']; ?></td>

</tr>

<tr>

<td>Total Harga</td>

<td>:</td>

<td>

Rp <?php echo number_format($data['total_harga'],0,",",".");?>

</td>

</tr>

<tr>

<td>Tanggal</td>

<td>:</td>

<td><?php echo $data['tanggal_pesanan']; ?></td>

</tr>

</table>

<a
href="dashboard.php"
class="btn">

Kembali ke Marketplace

</a>

</div>

</body>

</html>