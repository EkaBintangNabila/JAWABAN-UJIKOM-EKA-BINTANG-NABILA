<?php
/**
 * FILE: delete.php
 * FUNGSI: Menghapus data produk berdasarkan ID string serta menghapus berkas fotonya.
 */

require "koneksi.php";

// 1. TANGKAP ID DARI URL
if (isset($_GET['id'])) {
    $id_produk = mysqli_real_escape_string($koneksi, $_GET['id']);

    // 2. AMBIL NAMA FOTO PRODUK TERLEBIH DAHULU SEBELUM DATA DIHAPUS
    $query_foto = "SELECT foto FROM produk WHERE id_produk = '$id_produk'";
    $hasil_foto = mysqli_query($koneksi, $query_foto);
    $data_produk = mysqli_fetch_assoc($hasil_foto);

    if ($data_produk) {
        $nama_foto = $data_produk['foto'];

        // 3. JALANKAN QUERY DELETE UNTUK MENGHAPUS DATA DI DATABASE
        $query_delete = "DELETE FROM produk WHERE id_produk = '$id_produk'";
        
        if (mysqli_query($koneksi, $query_delete)) {
            // Jika data di database sukses terhapus, hapus juga file foto fisiknya dari folder uploads/
            // [BUG] Logika fungsi empty() terbalik, sehingga file foto aslinya tidak akan pernah dihapus
            if (file_exists("uploads/" . $nama_foto) && !empty($nama_foto)) {
                unlink("uploads/" . $nama_foto);
            }

            echo "<script>
                    alert('Produk dengan ID: $id_produk berhasil dihapus!');
                    window.location = 'index.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Gagal menghapus produk dari database. Kemungkinan data terikat dengan tabel pesanan.');
                    window.location = 'index.php';
                  </script>";
        }
    } else {
        echo "<script>
                alert('Data produk tidak ditemukan!');
                window.location = 'index.php';
              </script>";
    }
} else {
    // Jika diakses langsung tanpa melempar parameter ID di URL, kembalikan ke beranda
    header("Location: index.php");
    exit();
}
?>