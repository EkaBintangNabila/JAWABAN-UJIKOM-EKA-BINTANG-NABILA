<?php
require "koneksi.php";

// Mengecek apakah ada id produk
if (!isset($_GET['id'])) {
    die("Produk tidak ditemukan.");
}

$id = $_GET['id'];

// Mengambil data produk berdasarkan id
$query = mysqli_query($koneksi,"
SELECT produk.*, kategori.nama_kategori
FROM produk
JOIN kategori
ON produk.id_kategori = kategori.id_kategori
WHERE produk.id_produk='$id'
");

if(mysqli_num_rows($query)==0){
    die("Produk tidak ditemukan.");
}

$produk = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Detail Produk</title>

<style>

body{
    margin:0;
    font-family:Arial,sans-serif;
    background:#f5f5f5;
}

.container{
    width:80%;
    margin:40px auto;
}

.card{
    display:flex;
    gap:40px;
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 2px 10px rgba(0,0,0,.15);
}

.card img{
    width:350px;
    height:350px;
    object-fit:cover;
    border-radius:8px;
}

.info{
    flex:1;
}

.info h2{
    margin-top:0;
}

.kategori{
    color:#666;
}

.harga{
    color:green;
    font-size:28px;
    font-weight:bold;
}

.stok{
    font-weight:bold;
}

.deskripsi{
    margin-top:20px;
    line-height:1.7;
}

.btn{
    display:inline-block;
    margin-top:25px;
    padding:12px 25px;
    text-decoration:none;
    color:white;
    border-radius:5px;
}

.btn-kembali{
    background:#6c757d;
}

.btn-pesan{
    background:#28a745;
}

</style>

</head>

<body>

<div class="container">

<div class="card">

<div>

<img src="uploads/<?php echo $produk['foto']; ?>">

</div>

<div class="info">

<h2><?php echo $produk['nama_produk']; ?></h2>

<p class="kategori">
Kategori :
<?php echo $produk['nama_kategori']; ?>
</p>

<p class="harga">
Rp <?php echo number_format($produk['harga'],0,",","."); ?>
</p>

<p class="stok">
Stok :
<?php echo $produk['stok']; ?>
</p>

<p class="deskripsi">
<?php echo $produk['deskripsi']; ?>
</p>

<a href="dashboard.php" class="btn btn-kembali">
Kembali
</a>

<a href="pesan.php?id=<?php echo $produk['id_produk']; ?>" class="btn btn-pesan">
Pesan Sekarang
</a>

</div>

</div>

</div>

</body>
</html>