<?php
/**
 * FILE: edit.php
 * FUNGSI: Menampilkan form edit dan memuat data lama produk berdasarkan ID.
 */

require "koneksi.php";

// 1. Pastikan parameter ID ada di URL
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
} 

$id_produk = mysqli_real_escape_string($koneksi, $_GET['id']);

// 2. Ambil data produk lama dari database
$query_produk = "SELECT * FROM produk WHERE id_produk = '$id_produk'";
$hasil_produk = mysqli_query($koneksi, $query_produk);
$produk       = mysqli_fetch_assoc($hasil_produk); 

// Jika data tidak ditemukan
if (!$produk) {
    echo "<script>alert('Data produk tidak ditemukan!'); window.location='index.php';</script>";
    exit();
}

// 3. Ambil data kategori untuk pilihan di dropdown
$query_kategori = "SELECT * FROM kategori ORDER BY nama_kategori ASC";
$hasil_kategori = mysqli_query($koneksi, $query_kategori);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk - <?php echo $id_produk; ?></title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 30px auto; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h2 { margin-top: 0; color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input[type="text"], .form-group input[type="number"], .form-group select, .form-group textarea {
            width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; font-size: 14px;
        }
        .form-group textarea { resize: vertical; height: 100px; }
        .preview-foto { margin-top: 5px; margin-bottom: 10px; }
        .preview-foto img { max-width: 120px; border-radius: 4px; border: 1px solid #ddd; display: block; }
        .btn-grup { display: flex; gap: 10px; margin-top: 20px; }
        .btn { padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 14px; cursor: pointer; border: none; }
        .btn-update { background-color: #ffc107; color: #333; }
        .btn-kembali { background-color: #6c757d; color: white; text-align: center; }
    </style>
</head>
<body>

<div class="container">
    <h2>Form Edit Produk (ID: <?php echo $id_produk; ?>)</h2>
    
    <form action="proses_edit.php" method="POST" enctype="multipart/form-data">
        
        <input type="hidden" name="id_produk" value="<?php echo $produk['id_produk']; ?>">
        
        <input type="hidden" name="foto_lama" value="<?php echo htmlspecialchars($produk['foto']); ?>">
        
        <div class="form-group">
            <label for="nama_produk">Nama Produk</label>
            <input type="text" id="nama_produk" name="nama_produk" required value="<?php htmlspecialchars($produk['nama_produk']); ?>">
        </div>

        <div class="form-group">
            <label for="id_kategori">Kategori</label>
            <select id="id_kategori" name="id_kategori" required>
                <?php while ($kat = mysqli_fetch_assoc($hasil_kategori)) { ?>
                    <option value="<?php echo $kat['id_kategori']; ?>" <?php echo ($kat['id_kategori'] == $produk['id_kategori']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($kat['nama_kategori']); ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <div class="form-group">
            <label for="harga">Harga (Rp)</label>
            <input type="number" id="harga" name="harga" required value="<?php echo (int)$produk['harga']; ?>">
        </div>

        <div class="form-group">
            <label for="stok">Stok</label>
            <input type="number" id="stok" name="stok" required value="<?php echo $produk['stok']; ?>" min="0">
        </div>

        <div class="form-group">
            <label for="deskripsi">Deskripsi Produk</label>
            <textarea id="deskripsi" name="deskripsi"><?php echo htmlspecialchars($produk['deskripsi']); ?></textarea>
        </div>

        <div class="form-group">
            <label>Foto Produk Saat Ini</label>
            <div class="preview-foto">
                <img src="uploads/<?php echo htmlspecialchars($produk['foto']); ?>" alt="Foto Produk">
            </div>
            <label for="foto">Ganti Foto Baru *(Kosongkan jika tidak ingin diubah)</label>
            <input type="file" id="foto" name="foto" accept="image/*">
        </div>

        <div class="btn-grup">
            <button type="submit" name="update" class="btn btn-update">Simpan Perubahan</button>
            <a href="index.php" class="btn btn-kembali">Kembali</a>
        </div>
    </form>
</div>

</body>
</html>