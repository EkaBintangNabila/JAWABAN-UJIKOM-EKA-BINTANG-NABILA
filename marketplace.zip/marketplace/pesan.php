<?php
require "koneksi.php";

if(!isset($_GET['id'])){
    die("Produk tidak ditemukan.");
}

$id = $_GET['id'];

$query = mysqli_query($koneksi,"SELECT * FROM produk WHERE id_produk='$id'");

if(mysqli_num_rows($query)==0){
    die("Produk tidak ditemukan.");
}

$produk = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Form Pemesanan</title>

<style>

body{
    font-family:Arial;
    background:#f5f5f5;
    margin:0;
}

.container{
    width:500px;
    margin:40px auto;
    background:white;
    padding:25px;
    border-radius:8px;
    box-shadow:0 0 10px rgba(0,0,0,.2);
}

h2{
    text-align:center;
}

.info{
    background:#f1f1f1;
    padding:15px;
    border-radius:5px;
    margin-bottom:20px;
}

label{
    display:block;
    margin-top:15px;
}

input{
    width:100%;
    padding:10px;
    border:1px solid #ccc;
    border-radius:5px;
    box-sizing:border-box;
}

button{

width:100%;
padding:12px;
margin-top:20px;
background:#28a745;
border:none;
color:white;
border-radius:5px;
cursor:pointer;

}

button:hover{

background:#218838;

}

a{

display:inline-block;
margin-top:15px;
text-decoration:none;

}

</style>

</head>

<body>

<div class="container">

<h2>Form Pemesanan</h2>

<div class="info">

<p><b>Produk :</b>
<?php echo $produk['nama_produk']; ?>
</p>

<p><b>Harga :</b>

Rp <?php echo number_format($produk['harga'],0,",",".");?>

</p>

<p><b>Stok :</b>

<?php echo $produk['stok'];?>

</p>

</div>

<form action="proses_pesan.php" method="POST">

<input
type="hidden"
name="id_produk"
value="<?php echo $produk['id_produk'];?>">

<input
type="hidden"
name="harga"
value="<?php echo $produk['harga'];?>">

<label>Nama Pembeli</label>

<input
type="text"
name="nama_pembeli"
required>

<label>Nomor HP</label>

<input
type="text"
name="no_hp"
required>

<label>Jumlah Pesanan</label>

<input
type="number"
name="jumlah"
min="1"
max="<?php echo $produk['stok'];?>"
required>

<button type="submit">

Pesan Sekarang

</button>

</form>

<a href="detail.php?id=<?php echo $produk['id_produk'];?>">

← Kembali

</a>

</div>

</body>
</html>